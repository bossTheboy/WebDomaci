package com.example.demo1;

import reade.write.ReadeWrite;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "porucivanje", value = "/porucivanje")
public class Porucivanje extends HttpServlet {

    public static ArrayList<String> users = new ArrayList<>();
    public static  final String LOCK = "lock";
    public Porucivanje() {}


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");

        PrintWriter out = resp.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + "Vasa porudzbina:" + "</h1>");
        // out.println("<br>");
        out.println("<h3>" + "Ponedeljak: " + req.getSession().getAttribute("ponedeljak") + "<br><br>"
                + "Utorak: " + req.getSession().getAttribute("utorak") + "<br><br>"
                + "Sreda: " + req.getSession().getAttribute("sreda") + "<br><br>"
                + "Cetvrtak: " + req.getSession().getAttribute("cetvrtak") + "<br><br>"
                + "Petak: " + req.getSession().getAttribute("petak") + " "
                + "</h3>");
        out.println("</body></html>");

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //provera logovanja korisnika ?
        if(users.isEmpty() || !users.contains(req.getSession().getId())) {
            ReadeWrite readeWrite = new ReadeWrite();
            String pon = (String) req.getParameter("poninp");
            String uto = (String) req.getParameter("utoinp");
            String sre = (String) req.getParameter("sreinp");
            String cet = (String) req.getParameter("cetinp");
            String pet = (String) req.getParameter("petinp");

            if (pon == null || pon.equals("") || uto == null || uto.equals("") || sre == null || sre.equals("")
                    || cet == null || cet.equals("") || pet == null || pet.equals("")) {
                resp.getOutputStream().println("Porudzbine su obavezne, moraju se uneti vrednosti za sva polja !");
                resp.setStatus(403);
                return;
            }

            req.getSession().setAttribute("ponedeljak", pon);
            req.getSession().setAttribute("utorak", uto);
            req.getSession().setAttribute("sreda", sre);
            req.getSession().setAttribute("cetvrtak", cet);
            req.getSession().setAttribute("petak", pet);

            String ponp = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\pon.TXT";
            String utop = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\uto.TXT";
            String srep = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\sre.TXT";

            String cetp = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\cet.TXT";
            String petp = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\pet.TXT";

            readeWrite.ponedeljakRw(ponp, pon);
            readeWrite.utorakRw(utop, uto);
            readeWrite.sredaRw(srep, sre);
            readeWrite.cetvrtakRw(cetp, cet);
            readeWrite.petakRw(petp, pet);

            synchronized (LOCK) {
                users.add(req.getSession().getId());
            }

            resp.sendRedirect("/porucivanje");
        }
        //provera logovanja korisnika ?
        else{
            resp.getOutputStream().println("Zadati korisnik je vec porucio jelo!");
            resp.setStatus(403);
            return;
        }
    }
}
