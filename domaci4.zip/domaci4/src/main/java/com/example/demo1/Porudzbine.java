package com.example.demo1;

import reade.write.ReadeWrite;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "porudzbina", value = "/porudzbine")
public class Porudzbine extends HttpServlet {

    public Porudzbine(){}

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ReadeWrite readeWrite = new ReadeWrite();
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        String pass = readeWrite.passwordR("C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\pass.TXT");

        out.println("<html><body>");

        if(req.getParameter("password") != null){
            if(req.getParameter("password").equals(pass)){
                out.println("<form action=\"/porudzbine\" method=\"post\">"); out.println(" <br><br>");
                out.println(" <input name=\"submit\" type=\"submit\" value=\"Obrisi\"/>"); out.println(" <br><br>");

                String pon[] = readeWrite.ponP();
                out.println("<h3>Ponedeljak: </h3>");
                out.println("<h4>" + "Pileci file: " + pon[0] + "<br>" + "Becar sa svinjskim mesom: " + pon[1]  + "<br>"+ "Musaka krompir: " + pon[2] + "</h4>");out.println("<br>");
                String uto[] = readeWrite.utoP();
                out.println("<h3>Utorak: </h3>");
                out.println("<h4>" + "Grasak sa piletinom: " + uto[0] + "<br>" + "Sarma: " + uto[1]  + "<br>"+ "Vojnicki pasulj: " + uto[2] + "</h4>");out.println("<br>");
                String sre[] = readeWrite.sreP();
                out.println("<h3>Sreda: </h3>");
                out.println("<h4>" + "Cufte u sosu: " + sre[0] + "<br>" + "Pohovanja piletina: " + sre[1]  + "<br>"+ "Karadjordjeva: " + sre[2] + "</h4>");out.println("<br>");
                String cet[] = readeWrite.cetP();
                out.println("<h3>Cetvrtak: </h3>");
                out.println("<h4>" + "Becka snicla: " + cet[0] + "<br>" + "Cevapi i pomfrit: " + cet[1]  + "<br>"+ "Rebarca u kajmaku: " + cet[2] + "</h4>");out.println("<br>");
                String pet[] = readeWrite.petP();
                out.println("<h3>Petak: </h3>");
                out.println("<h4>" + "Pizza: " + pet[0] + "<br>" + "Lasanja: " + pet[1]  + "<br>"+ "Spagete: " + pet[2] + "</h4>");out.println("<br>");

                out.println("</form>");


            }

            else{
                out.println("<h1>" + "Sifra nije odgovarajuca" + "</h1>");
                resp.setStatus(403);
                return;
            }
        }

        else{
            out.println("<h1>" + "Sifra mora da se unese" + "</h1>");
            resp.setStatus(403);
            return;
        }
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        ReadeWrite readeWrite = new ReadeWrite();
        readeWrite.removeAll();
        synchronized (Porucivanje.LOCK) {
            Porucivanje.users.clear();//provera logovanja korisnika ?
        }
        resp.sendRedirect("/porudzbine");
    }
}

