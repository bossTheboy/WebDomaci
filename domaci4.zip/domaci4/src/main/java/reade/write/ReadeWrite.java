package reade.write;

import java.io.*;

public class ReadeWrite {

    public ReadeWrite() {
    }

    public void ponedeljakRw(String path, String pon) throws IOException {
        int p1, p2, p3;

        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));
        String line = "ss";
        String yy = (String) pons.readLine();

        if (yy != null) {
            line = yy;
        } else if (yy == null) {
            line = "0,0,0";
        }

        String s[] = line.split(",");
        p1 = Integer.parseInt(s[0]);
        p2 = Integer.parseInt(s[1]);
        p3 = Integer.parseInt(s[2]);

        if (pon.trim().equals("Pileci file")) {
            p1 += 1;
        } else if (pon.trim().equals("Becar sa svinjskim mesom")) {
            p2 += 1;
        } else if (pon.trim().equals("Musaka krompir")) {
            p3 += 1;
        }
        System.out.println("pon: " + pon + " " + p1 + " " + p2 + " " + p3);

        String str = Integer.toString(p1);
        String str1 = Integer.toString(p2);
        String str2 = Integer.toString(p3);
        String wr = str + "," + str1 + "," + str2;

        BufferedWriter fileWriter = new BufferedWriter(new FileWriter(path));
        fileWriter.write(wr);
        fileWriter.close();


    }

    public void utorakRw(String path, String uto) throws IOException {
        int p1, p2, p3;

        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));
        String line = "ss";
        String yy = (String) pons.readLine();

        if (yy != null) {
            line = yy;
        } else if (yy == null) {
            line = "0,0,0";
        }

        String s[] = line.split(",");
        p1 = Integer.parseInt(s[0]);
        p2 = Integer.parseInt(s[1]);
        p3 = Integer.parseInt(s[2]);

        if (uto.trim().equals("Grasak sa piletinom")) {
            p1 += 1;
        } else if (uto.trim().equals("Sarma")) {
            p2 += 1;
        } else if (uto.trim().equals("Vojnicki pasulj")) {
            p3 += 1;
        }
        System.out.println("uto: " + uto + " " + p1 + " " + p2 + " " + p3);

        String str = Integer.toString(p1);
        String str1 = Integer.toString(p2);
        String str2 = Integer.toString(p3);
        String wr = str + "," + str1 + "," + str2;

        BufferedWriter fileWriter = new BufferedWriter(new FileWriter(path));
        fileWriter.write(wr);
        fileWriter.close();


    }

    public void sredaRw(String path, String sre) throws IOException {
        int p1, p2, p3;

        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));
        String line = "ss";
        String yy = (String) pons.readLine();

        if (yy != null) {
            line = yy;
        } else if (yy == null) {
            line = "0,0,0";
        }

        String s[] = line.split(",");
        p1 = Integer.parseInt(s[0]);
        p2 = Integer.parseInt(s[1]);
        p3 = Integer.parseInt(s[2]);

        if (sre.trim().equals("Cufte u sosu")) {
            p1 += 1;
        } else if (sre.trim().equals("Pohovanja piletina")) {
            p2 += 1;
        } else if (sre.trim().equals("Karadjordjeva")) {
            p3 += 1;
        }
        System.out.println("sre: " + sre + " " + p1 + " " + p2 + " " + p3);

        String str = Integer.toString(p1);
        String str1 = Integer.toString(p2);
        String str2 = Integer.toString(p3);
        String wr = str + "," + str1 + "," + str2;

        BufferedWriter fileWriter = new BufferedWriter(new FileWriter(path));
        fileWriter.write(wr);
        fileWriter.close();


    }

    public void cetvrtakRw(String path, String cet) throws IOException {
        int p1, p2, p3;

        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));
        String line = "ss";
        String yy = (String) pons.readLine();

        if (yy != null) {
            line = yy;
        } else if (yy == null) {
            line = "0,0,0";
        }

        String s[] = line.split(",");
        p1 = Integer.parseInt(s[0]);
        p2 = Integer.parseInt(s[1]);
        p3 = Integer.parseInt(s[2]);

        if (cet.trim().equals("Becka snicla")) {
            p1 += 1;
        } else if (cet.trim().equals("Cevapi i pomfrit")) {
            p2 += 1;
        } else if (cet.trim().equals("Rebarca u kajmaku")) {
            p3 += 1;
        }
        System.out.println("cet: " + cet + " " + p1 + " " + p2 + " " + p3);

        String str = Integer.toString(p1);
        String str1 = Integer.toString(p2);
        String str2 = Integer.toString(p3);
        String wr = str + "," + str1 + "," + str2;

        BufferedWriter fileWriter = new BufferedWriter(new FileWriter(path));
        fileWriter.write(wr);
        fileWriter.close();


    }

    public void petakRw(String path, String pet) throws IOException {
        int p1, p2, p3;

        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));
        String line = "ss";
        String yy = (String) pons.readLine();

        if (yy != null) {
            line = yy;
        } else if (yy == null) {
            line = "0,0,0";
        }

        String s[] = line.split(",");
        p1 = Integer.parseInt(s[0]);
        p2 = Integer.parseInt(s[1]);
        p3 = Integer.parseInt(s[2]);

        if (pet.trim().equals("Pizza")) {
            p1 += 1;
        } else if (pet.trim().equals("Lasanja")) {
            p2 += 1;
        } else if (pet.trim().equals("Spagete")) {
            p3 += 1;
        }
        System.out.println("pet: " + pet + " " + p1 + " " + p2 + " " + p3);

        String str = Integer.toString(p1);
        String str1 = Integer.toString(p2);
        String str2 = Integer.toString(p3);
        String wr = str + "," + str1 + "," + str2;

        BufferedWriter fileWriter = new BufferedWriter(new FileWriter(path));
        fileWriter.write(wr);
        fileWriter.close();


    }

    public String[] ponP() throws  IOException{
        String ret[] = new String[200];
        String path = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\pon.TXT";
        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));

        String str = pons.readLine();

        ret = str.split(",");

        return  ret;
    }

    public String[] utoP() throws  IOException{
        String ret[] = new String[200];
        String path = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\uto.TXT";
        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));

        String str = pons.readLine();

        ret = str.split(",");

        return  ret;
    }
    public String[] sreP() throws  IOException{
        String ret[] = new String[200];
        String path = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\sre.TXT";
        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));

        String str = pons.readLine();

        ret = str.split(",");

        return  ret;
    }

    public String[] cetP() throws  IOException{
        String ret[] = new String[200];
        String path = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\cet.TXT";
        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));

        String str = pons.readLine();

        ret = str.split(",");

        return  ret;
    }

    public String[] petP() throws  IOException{
        String ret[] = new String[200];
        String path = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\pet.TXT";
        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));

        String str = pons.readLine();

        ret = str.split(",");

        return  ret;
    }

    public void removeAll() throws  IOException{

        String path1 = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\pon.TXT";
        String path2 = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\uto.TXT";
        String path3 = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\sre.TXT";
        String path4 = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\cet.TXT";
        String path5 = "C:\\Users\\NIKOLA\\IdeaProjects\\domaci4\\nedelja\\pet.TXT";

        String str = "0,0,0";

        BufferedWriter fileWriter1 = new BufferedWriter(new FileWriter(path1));
        fileWriter1.write(str);
        fileWriter1.close();
        BufferedWriter fileWriter2 = new BufferedWriter(new FileWriter(path2));
        fileWriter2.write(str);
        fileWriter2.close();
        BufferedWriter fileWriter3 = new BufferedWriter(new FileWriter(path3));
        fileWriter3.write(str);
        fileWriter3.close();
        BufferedWriter fileWriter4 = new BufferedWriter(new FileWriter(path4));
        fileWriter4.write(str);
        fileWriter4.close();
        BufferedWriter fileWriter5 = new BufferedWriter(new FileWriter(path5));
        fileWriter5.write(str);
        fileWriter5.close();

    }

    public String passwordR(String path) throws IOException {
        String password = "";
        File ponf = new File(path);
        BufferedReader pons = new BufferedReader(new FileReader(ponf));

        password = (String) pons.readLine();

        return password;
    }

}
